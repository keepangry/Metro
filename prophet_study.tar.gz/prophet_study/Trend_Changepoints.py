#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/3 2:27 PM
# @Author  : yangsen
# @Site    : 
# @File    : Trend_Changepoints.py
# @Software: PyCharm

import pandas as pd
from fbprophet import Prophet

df = pd.read_csv('./examples/example_wp_log_peyton_manning.csv')
df.head()

"""
using the input argument changepoint_prior_scale. By default, this parameter is set to 0.05. 
Increasing it will make the trend more flexible:
Decreasing it will make the trend less flexible:

"""
m = Prophet(changepoint_range=0.9, changepoint_prior_scale=0.001)
# Specifying the locations of the changepoints
# m = Prophet(changepoints=['2014-01-01'])

m.fit(df)

future = m.make_future_dataframe(periods=365)
future.tail()

forecast = m.predict(future)
forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()



from fbprophet.plot import add_changepoints_to_plot
fig = m.plot(forecast)
a = add_changepoints_to_plot(fig.gca(), m, forecast)
fig.show()


