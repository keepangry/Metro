#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/3 3:04 PM
# @Author  : yangsen
# @Site    : 
# @File    : Non-DailyData.py
# @Software: PyCharm
import pandas as pd
from fbprophet import Prophet

df = pd.read_csv('./examples/example_yosemite_temps.csv')
m = Prophet(changepoint_prior_scale=0.01).fit(df)
future = m.make_future_dataframe(periods=300, freq='H')
fcst = m.predict(future)
fig = m.plot(fcst)