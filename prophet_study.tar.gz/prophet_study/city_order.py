#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/4 10:24 AM
# @Author  : yangsen
# @Site    : 
# @File    : city_order.py
# @Software: PyCharm

import pandas as pd
from fbprophet import Prophet


# 准备数据
origin_df = pd.read_csv('110100city_order.txt', delimiter="\t")
# df = origin_df.sort_index(by=["dt"], ascending=[True])
df = origin_df.sort_values(by=["dt"], ascending=[True])

ds = df[['dt']].applymap(lambda x: str(x)).applymap(lambda x: "%s-%s-%s" % (x[:4], x[4:6], x[6:]))
df.insert(0, 'ds', ds)
df.pop('city_id')
df.pop('dt')
df.columns = ['ds', 'y']
df = df.reset_index(drop=True)


playoffs = pd.DataFrame({
  'holiday': 'SpringFestival',
  'ds': pd.to_datetime(['2016-02-08', '2017-01-28',
                        '2018-02-16', '2019-02-05']),
  'lower_window': -5,
  'upper_window': 9,
})
superbowls = pd.DataFrame({
  'holiday': 'NationalDay',
  'ds': pd.to_datetime(['2016-10-01', '2017-10-01', '2018-10-01', '2019-10-01']),
  'lower_window': -2,
  'upper_window': 7,
})
holidays = pd.concat((playoffs, superbowls))


# 进行分析
m = Prophet(yearly_seasonality=True, changepoint_range=0.8, changepoint_prior_scale=0.1)
# m = Prophet(holidays=holidays)
m.fit(df)

future = m.make_future_dataframe(periods=365)
# m.make_holiday_features(future, holidays=holidays)
# m.construct_holiday_dataframe

forecast = m.predict(future)
fig1 = m.plot(forecast)
fig1.savefig("110100")


fig2 = m.plot_components(forecast)
fig2.savefig("110100_components")