#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/3 2:57 PM
# @Author  : yangsen
# @Site    : 
# @File    : Outliers.py
# @Software: PyCharm
import pandas as pd
from fbprophet import Prophet

df = pd.read_csv('./examples/example_wp_log_R_outliers1.csv')
m = Prophet()
m.fit(df)

future = m.make_future_dataframe(periods=1096)
forecast = m.predict(future)
fig = m.plot(forecast)


df.loc[(df['ds'] > '2010-01-01') & (df['ds'] < '2011-01-01'), 'y'] = None
model = Prophet().fit(df)
fig = model.plot(model.predict(future))