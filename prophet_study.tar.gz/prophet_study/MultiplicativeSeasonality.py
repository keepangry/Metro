#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/3 2:48 PM
# @Author  : yangsen
# @Site    : 
# @File    : MultiplicativeSeasonality.py
# @Software: PyCharm
import pandas as pd
from fbprophet import Prophet


df = pd.read_csv('./examples/example_air_passengers.csv')
# m = Prophet()
m = Prophet(seasonality_mode='multiplicative')

m = Prophet(seasonality_mode='multiplicative')
m.add_seasonality('quarterly', period=91.25, fourier_order=8, mode='additive')
# m.add_regressor('regressor', mode='additive')

m.fit(df)
future = m.make_future_dataframe(50, freq='MS')
forecast = m.predict(future)
fig = m.plot(forecast)


#fig = m.plot_components(forecast)
