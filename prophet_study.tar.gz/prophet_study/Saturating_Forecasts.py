#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/3 2:16 PM
# @Author  : yangsen
# @Site    : 
# @File    : Saturating_Forecasts.py
# @Software: PyCharm

import pandas as pd
from fbprophet import Prophet

df = pd.read_csv('./examples/example_wp_log_R.csv')

# 经验设置的 市场容量。可以是固定值也可以跟据时间变化，每个时间点均设置。
df['cap'] = 8.5

m = Prophet(growth='logistic')
m.fit(df)

# Forecasting Growth
future = m.make_future_dataframe(periods=1826)

# future['cap'] = 8.5
# fcst = m.predict(future)
# fig = m.plot(fcst)
# fig.show()


# Saturating Minimum

df['y'] = 10 - df['y']
df['cap'] = 6
df['floor'] = 1.5
future['cap'] = 6
future['floor'] = 1.5
m = Prophet(growth='logistic')
m.fit(df)
fcst = m.predict(future)
fig = m.plot(fcst)